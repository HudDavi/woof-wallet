# Attribution

1. Copy to clipboard

* Source: https://www.iconfinder.com/icons/7124212/copy_clipboard_icon
* Author: Steve Schoger
* Collection: Heroicons UI pack
