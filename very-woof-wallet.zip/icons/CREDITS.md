# Attribution

1. Package icon

* Source: https://www.flaticon.com/free-icon/package_2945609
* Author: Freepik
* Collection: Box icons

2. Doge icon

* Source: https://icons8.com/icon/PjUpgs6o2IFx/doge
* Collection: Windows 11 Color
